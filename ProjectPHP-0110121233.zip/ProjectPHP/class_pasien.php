<?php
class Pasien{
    public $nama;
    public $gender;
    public $tgl_lahir;
    public $tmp_lahir;

}
?>
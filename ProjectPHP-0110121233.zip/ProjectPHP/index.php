<?php
    require_once 'header.php';
?>
<?php
    require_once 'sidebar.php';
?>
<?php
    require_once 'Praktikum 2/tampilan.php';
?>
<?php
    require_once 'footer.php';
?>